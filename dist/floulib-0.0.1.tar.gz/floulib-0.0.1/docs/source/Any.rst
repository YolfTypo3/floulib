.. -*- coding: utf-8 -*-

Any
=====

.. currentmodule:: floulib

.. autoclass:: Any   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__








