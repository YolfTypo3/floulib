.. -*- coding: utf-8 -*-

Defuzzify
=========

.. currentmodule:: floulib

.. autoclass:: Defuzzify   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__
