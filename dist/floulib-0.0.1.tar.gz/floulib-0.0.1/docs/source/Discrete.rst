.. -*- coding: utf-8 -*-

Discrete
========

.. currentmodule:: floulib

.. autoclass:: Discrete   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: color, __weakref__
    








