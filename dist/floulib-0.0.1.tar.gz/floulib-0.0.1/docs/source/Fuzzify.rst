.. -*- coding: utf-8 -*-

Fuzzify
=======

.. currentmodule:: floulib

.. autoclass:: Fuzzify   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__
    








