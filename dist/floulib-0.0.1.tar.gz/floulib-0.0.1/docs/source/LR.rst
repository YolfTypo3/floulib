.. -*- coding: utf-8 -*-

LR
==

.. currentmodule:: floulib

.. autoclass:: LR  
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__
 








