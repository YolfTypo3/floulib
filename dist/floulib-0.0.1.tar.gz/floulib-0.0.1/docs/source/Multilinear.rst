.. -*- coding: utf-8 -*-

Multilinear
===========

.. currentmodule:: floulib

.. autoclass:: Multilinear   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: color, __weakref__
 







