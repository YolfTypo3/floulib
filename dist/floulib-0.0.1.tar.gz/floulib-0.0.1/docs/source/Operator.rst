.. -*- coding: utf-8 -*-

Operator
========

.. currentmodule:: floulib

.. autoclass:: Operator   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__








