.. -*- coding: utf-8 -*-

Plot
====

.. currentmodule:: floulib

.. autoclass:: Plot   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__








