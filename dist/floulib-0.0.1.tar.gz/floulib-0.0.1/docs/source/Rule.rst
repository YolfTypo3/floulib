.. -*- coding: utf-8 -*-

Rule
====

.. currentmodule:: floulib

.. autoclass:: Rule   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__








