.. -*- coding: utf-8 -*-

Rules
=====

.. currentmodule:: floulib

.. autoclass:: Rules   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__









