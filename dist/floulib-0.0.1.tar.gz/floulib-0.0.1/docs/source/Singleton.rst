.. -*- coding: utf-8 -*-

Singleton
=========

.. currentmodule:: floulib

.. autoclass:: Singleton   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__







