.. -*- coding: utf-8 -*-

Term
====

.. currentmodule:: floulib

.. autoclass:: Term   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__

