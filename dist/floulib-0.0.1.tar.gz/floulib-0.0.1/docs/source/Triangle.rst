.. -*- coding: utf-8 -*-

Triangle
========

.. currentmodule:: floulib

.. autoclass:: Triangle  
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__









