.. -*- coding: utf-8 -*-

Variable
========

.. currentmodule:: floulib

.. autoclass:: Variable   
   :show-inheritance: 
   :members: 
   :special-members:
   :member-order: bysource
   :exclude-members: __weakref__







