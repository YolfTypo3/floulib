.. -*- coding: utf-8 -*-

API
===


.. toctree::
   :maxdepth: 2
   
   Any
   Defuzzify
   Discrete
   DistToPi
   DistToPiMultilinear
   Fuzzify
   LR
   Operator
   Multilinear
   Plot
   Rectangle
   Rule
   Rules
   Singleton
   Smiley
   Term
   Terms
   Trapezoid
   Triangle
   Variable


     

    








