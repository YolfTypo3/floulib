.. floulib documentation master file, created by
   sphinx-quickstart on Sat Jun  3 08:40:30 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Floulib Documentation
=====================

The library floulib is a library for fuzzy logic. It was designed to implement 
exercices proposed in the second edition of the book in French "Logique floue : exercices corrigés" 
by Bernadette Bouchon-Meunier, Laurent Foulloy, Mohammed Ramdani, Cépadues-Editions.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
